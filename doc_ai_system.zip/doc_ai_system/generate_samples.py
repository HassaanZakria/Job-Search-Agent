"""
generate_samples.py
-------------------
Generates sample documents (invoices, resumes, utility bills, others)
as .txt files so the system can be tested without real PDFs.
Run: python generate_samples.py
"""

import os

SAMPLE_DIR = "sample_docs"
os.makedirs(SAMPLE_DIR, exist_ok=True)

samples = {
    # ── INVOICES ──────────────────────────────────────────────────────────
    "invoice_1.txt": """
INVOICE

Invoice Number: INV-2025-0042
Date: 2025-01-15
Due Date: 2025-02-15

Bill To:
  TechSpark Solutions
  45 Innovation Blvd, San Francisco, CA 94103

From:
  ACME Supplies Ltd.
  100 Commerce Street, New York, NY 10001

Services:
  Cloud Storage (100 GB)       $120.00
  API Access (Pro Tier)        $180.00
  Support Package              $50.00

Subtotal: $350.00
Tax (10%): $35.00
TOTAL DUE: $385.00

Payment due within 30 days. Wire transfer accepted.
""",

    "invoice_2.txt": """
TAX INVOICE

Invoice #: INV-8801
Issued: 2025-03-10
Payment Due: 2025-04-10

Vendor: Globex Corporation
Client: Wayne Enterprises, Gotham City

Description                     Qty    Unit Price    Amount
---------------------------------------------------------------
Software Licences (Annual)        5      $200.00    $1,000.00
Onboarding & Setup                1      $500.00      $500.00
Priority Support (3 months)       1      $300.00      $300.00

Subtotal                                            $1,800.00
Discount (5%)                                        -$90.00
VAT (15%)                                            $256.50
TOTAL AMOUNT DUE                                   $1,966.50

Bank: First National Bank | Account: 0045-8812-99 | SWIFT: FNBKUS33
""",

    "invoice_3.txt": """
COMMERCIAL INVOICE

Invoice No: INV-2024-77C
Date: December 3, 2024

From: Pinnacle Printing Co.
      889 Inkwell Ave, Austin, TX 78701

To: Sunrise Marketing Agency
    210 Campaign Road, Dallas, TX 75201

Items:
- Brochure Print (500 units)  ...........  $875.00
- Business Cards (1000 units)  ..........  $145.00
- Banner (3x6 ft, 2 units)  .............  $230.00

Total: $1,250.00

Terms: Net-30. Cheque payable to Pinnacle Printing Co.
""",

    # ── RESUMES ───────────────────────────────────────────────────────────
    "resume_1.txt": """
JOHN MICHAEL DOE
johndoe@email.com | (415) 555-0192 | LinkedIn: linkedin.com/in/johndoe
San Francisco, CA

SUMMARY
Results-driven software engineer with 7 years of experience building
scalable web applications and distributed systems.

EXPERIENCE
Senior Software Engineer — Dropbox, San Francisco        2021–Present
  • Led a team of 4 engineers to redesign the file-sync pipeline.
  • Reduced latency by 40% using gRPC and async processing.

Software Engineer — Twilio, San Francisco                2018–2021
  • Built REST APIs serving 50M+ requests/day.
  • Mentored 3 junior engineers.

Junior Developer — Freelance                             2017–2018
  • Developed e-commerce storefronts using Django and React.

EDUCATION
B.Sc. Computer Science — UC Berkeley, 2017

SKILLS
Python, Go, Kubernetes, PostgreSQL, Redis, AWS, Docker
""",

    "resume_2.txt": """
PRIYA SHARMA
priya.sharma@outlook.com
+44 7700 900 456

PROFESSIONAL PROFILE
Marketing professional with 4 years of experience in digital campaigns,
brand strategy, and analytics. Proficient in data-driven decision making.

WORK HISTORY
Digital Marketing Manager  |  PixelBridge Ltd., London    2022–2025
 - Managed £500k annual ad budget across Google and Meta platforms.
 - Grew organic traffic by 65% through SEO and content strategy.

Marketing Analyst  |  BlueWave Agency, Manchester         2021–2022
 - Built automated dashboards in Tableau for campaign performance.

EDUCATION
MSc Marketing Analytics — University of Manchester, 2021
BSc Business — University of Leeds, 2019

CONTACT
Email: priya.sharma@outlook.com | Phone: +44 7700 900 456
""",

    "resume_3.txt": """
CARLOS MENDEZ
carlos.mendez88@gmail.com | (305) 678-4321 | Miami, FL

Objective:
Experienced data scientist with 9 years in machine learning, NLP, and
large-scale data pipelines seeking a senior role in a research-driven team.

Professional Experience:
Lead Data Scientist | NovaTech Analytics, Miami          2019 – Present
  Designed ML models for fraud detection, reducing false positives by 30%.

Data Scientist | HealthStat Corp, New York               2015 – 2019
  Built NLP pipelines to extract clinical entities from unstructured notes.

Junior Analyst | DataXperts LLC, Miami                   2014 – 2015
  Performed EDA and statistical modeling on financial datasets.

Education:
Ph.D. Statistics — Florida State University, 2014

Technical Skills:
Python, R, Spark, TensorFlow, Scikit-learn, SQL, Airflow
""",

    # ── UTILITY BILLS ─────────────────────────────────────────────────────
    "utility_bill_1.txt": """
METROPOLITAN ELECTRIC COMPANY
Customer Service: 1-800-555-0199

ELECTRICITY BILL

Account Number: 45-8812-00321
Billing Period: January 1, 2025 – January 31, 2025
Bill Date: February 3, 2025
Due Date: February 28, 2025

Customer:
  Sarah Johnson
  78 Maple Street, Apt 3B
  Portland, OR 97201

Meter Readings:
  Previous Reading:  14,250 kWh
  Current Reading:   14,692 kWh
  Usage This Period:    442 kWh

Charges:
  Energy Charge (442 kWh @ $0.12)     $53.04
  Distribution Charge                  $12.00
  Transmission Charge                   $5.50
  Renewable Energy Surcharge            $2.20
  State Tax                             $3.68

TOTAL AMOUNT DUE: $76.42

Pay online at www.metroel.com or mail your cheque.
""",

    "utility_bill_2.txt": """
SUNRIDGE GAS & ELECTRIC
Billing Statement

Account No: GE-00928-77
Service Address: 1420 Elm Drive, Austin, TX 78741
Bill Date: 2025-02-05
Payment Due: 2025-03-01

Account Holder: Marcus Thompson

NATURAL GAS USAGE
Billing Period: Jan 3 – Feb 2, 2025
Usage: 88 therms
Gas Supply Charge:              $62.48
Pipeline Delivery:              $14.30
Meter Charge:                    $5.00
Taxes & Regulatory Fees:         $6.22

ELECTRICITY USAGE
Usage: 615 kWh
Energy Charge (615 kWh):        $73.80
Distribution:                   $18.45
Subtotal Electric:              $92.25

──────────────────────────────────────
TOTAL AMOUNT DUE:              $180.25
──────────────────────────────────────

AutoPay enrolled. Amount will be debited on 2025-03-01.
""",

    "utility_bill_3.txt": """
CLEARWATER UTILITY DISTRICT
Water & Sewer Services

WATER BILL

Account Number: WTR-0044-1128
Service Period: Dec 15, 2024 – Jan 14, 2025
Statement Date: January 18, 2025
Due Date: February 10, 2025

Subscriber: Emily R. Nguyen
Address: 555 Birchwood Lane, Seattle, WA 98101

Consumption:
  Water Used: 18 CCF (roughly 13,464 gallons)
  Sewer Discharge: 16 CCF (estimated)

Bill Summary:
  Water Service Charge           $24.80
  Water Consumption (18 CCF)     $36.00
  Sewer Base Charge              $18.50
  Sewer Usage (16 CCF)           $32.00
  Stormwater Fee                  $8.75
  City Tax (3%)                   $3.60

TOTAL DUE: $123.65

For outages or emergencies call 1-877-555-FLOW
""",

    # ── OTHER / UNCLASSIFIABLE ─────────────────────────────────────────────
    "legal_contract.txt": """
SERVICE AGREEMENT

This Service Agreement ("Agreement") is entered into as of March 1, 2025,
by and between Alpha Consulting Group LLC ("Service Provider") and
Beta Retail Inc. ("Client").

1. SCOPE OF SERVICES
   The Service Provider agrees to provide management consulting services
   including operational reviews, process optimization, and strategic planning
   for a period of six (6) months.

2. COMPENSATION
   Client shall pay Service Provider a retainer of $8,000 per month,
   invoiced on the first business day of each month.

3. CONFIDENTIALITY
   Both parties agree to maintain the confidentiality of any proprietary
   information shared during the engagement.

4. TERMINATION
   Either party may terminate this agreement with 30 days written notice.

IN WITNESS WHEREOF, the parties have executed this Agreement.

__________________________       __________________________
Alpha Consulting Group LLC       Beta Retail Inc.
Date: March 1, 2025              Date: March 1, 2025
""",

    "research_article.txt": """
ABSTRACT

Title: Advancements in Federated Learning for Privacy-Preserving NLP

Authors: Dr. A. Kaur, Dr. T. Osei, Dr. M. Petrov
Journal: International Journal of Machine Learning Research, Vol. 14, 2025

Abstract:
Federated learning (FL) has emerged as a powerful paradigm for training
machine learning models across decentralised data sources without exposing
raw data. This paper presents a novel aggregation strategy — Adaptive
Gradient Clipping Federation (AGCF) — that reduces communication overhead
by 38% while preserving model accuracy within 1.2% of centralised baselines
on NLP benchmarks including GLUE and SuperGLUE.

Keywords: federated learning, privacy, NLP, gradient clipping, distributed ML

1. INTRODUCTION
Privacy regulations such as GDPR have accelerated interest in distributed
training paradigms. Traditional FL methods suffer from high variance in
gradient updates across heterogeneous clients, a problem we address with
AGCF by dynamically adjusting clipping thresholds per communication round.

2. METHODOLOGY
We evaluate AGCF on three FL setups: cross-silo (hospitals), cross-device
(mobile keyboards), and hybrid. Each setup uses 50–200 participating nodes.

Conclusion: AGCF advances the state-of-the-art in communication-efficient
federated NLP, with strong empirical results across all benchmarks.
""",

    "meeting_notes.txt": """
MEETING MINUTES

Project: Phoenix Platform Redesign
Date: April 14, 2025
Time: 10:00 AM – 11:30 AM EST
Location: Zoom (Meeting ID: 822-456-7890)

Attendees:
  - Rachel Kim (Product Manager)
  - Dev Patel (Lead Engineer)
  - Sonia Okafor (UX Designer)
  - Tom Hughes (QA Lead)

Agenda & Discussion:

1. Sprint 7 Review
   Dev reported all backend APIs for the notification module are complete.
   Three minor bugs remain open; targeted for fix by April 17.

2. UX Feedback
   Sonia presented revised wireframes for the dashboard. Team approved the
   new card layout. Accessibility audit scheduled for April 22.

3. QA Status
   Tom confirmed regression suite is at 87% pass rate. Load testing begins
   next Monday on staging environment.

4. Next Steps
   - Dev to close remaining bugs by April 17
   - Sonia to hand off design tokens to dev by April 18
   - Rachel to update the roadmap in Jira by April 16

Next Meeting: April 21, 2025 at 10:00 AM EST
""",
}

for filename, content in samples.items():
    path = os.path.join(SAMPLE_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content.strip())
    print(f"  Created: {path}")

print(f"\n✅  {len(samples)} sample documents created in '{SAMPLE_DIR}/'")

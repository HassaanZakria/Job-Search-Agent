"""
src/ingest.py
-------------
Handles reading and cleaning text from PDF and plain-text files.

Supported formats:
  • .pdf   – extracted via pdfminer.six (preferred) or PyPDF2 as fallback
  • .txt   – read directly with encoding detection

Public API:
  load_documents(folder_path: str) -> dict[filename, cleaned_text]
"""

import os
import re
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# ── PDF extraction ────────────────────────────────────────────────────────────

def _extract_pdf_pdfminer(path: str) -> str:
    """Primary PDF extractor using pdfminer.six."""
    from pdfminer.high_level import extract_text as pdfminer_extract
    return pdfminer_extract(path)


def _extract_pdf_pypdf(path: str) -> str:
    """Fallback PDF extractor using pypdf / PyPDF2."""
    try:
        import pypdf as pypdf_lib          # pypdf (maintained fork)
    except ImportError:
        import PyPDF2 as pypdf_lib         # legacy name

    text_parts = []
    with open(path, "rb") as fh:
        reader = pypdf_lib.PdfReader(fh)
        for page in reader.pages:
            text_parts.append(page.extract_text() or "")
    return "\n".join(text_parts)


def extract_pdf_text(path: str) -> str:
    """Extract text from a PDF, trying pdfminer first then PyPDF as fallback."""
    try:
        text = _extract_pdf_pdfminer(path)
        if text and text.strip():
            return text
    except Exception as exc:
        logger.debug("pdfminer failed for %s: %s — trying PyPDF", path, exc)

    try:
        return _extract_pdf_pypdf(path)
    except Exception as exc:
        logger.warning("All PDF extractors failed for %s: %s", path, exc)
        return ""


# ── Plain-text extraction ─────────────────────────────────────────────────────

def extract_text_file(path: str) -> str:
    """Read a plain-text file, trying UTF-8 then falling back to latin-1."""
    for enc in ("utf-8", "latin-1", "cp1252"):
        try:
            with open(path, "r", encoding=enc) as fh:
                return fh.read()
        except UnicodeDecodeError:
            continue
    logger.warning("Could not decode %s with any known encoding.", path)
    return ""


# ── Text cleaning ─────────────────────────────────────────────────────────────

def clean_text(raw: str) -> str:
    """
    Normalise whitespace and remove non-printable characters.

    Steps:
      1. Replace form-feeds and carriage returns with newlines.
      2. Collapse runs of blank lines (keep at most 2 consecutive).
      3. Strip leading/trailing whitespace on each line.
      4. Remove null bytes and other non-printable characters.
    """
    text = raw.replace("\r\n", "\n").replace("\r", "\n").replace("\f", "\n")
    # Remove non-printable characters except newline and tab
    text = re.sub(r"[^\x09\x0A\x20-\x7E\u00A0-\uFFFF]", " ", text)
    # Collapse excessive blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    # Strip trailing whitespace per line
    lines = [line.rstrip() for line in text.split("\n")]
    return "\n".join(lines).strip()


# ── Main loader ───────────────────────────────────────────────────────────────

SUPPORTED_EXTENSIONS = {".pdf", ".txt", ".text"}


def load_documents(folder_path: str) -> dict:
    """
    Read all supported documents from *folder_path*.

    Returns
    -------
    dict
        {filename: {"path": str, "text": str, "extension": str}}
        Files that could not be parsed are included with empty text and
        a warning is logged.
    """
    folder = Path(folder_path)
    if not folder.is_dir():
        raise FileNotFoundError(f"Document folder not found: {folder_path}")

    docs = {}
    files = sorted(
        p for p in folder.iterdir()
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS
    )

    if not files:
        logger.warning("No supported files found in %s", folder_path)
        return docs

    logger.info("Found %d file(s) in '%s'", len(files), folder_path)

    for file_path in files:
        ext = file_path.suffix.lower()
        logger.info("  Ingesting: %s", file_path.name)

        try:
            if ext == ".pdf":
                raw = extract_pdf_text(str(file_path))
            else:
                raw = extract_text_file(str(file_path))
        except Exception as exc:
            logger.error("Failed to read %s: %s", file_path.name, exc)
            raw = ""

        docs[file_path.name] = {
            "path": str(file_path),
            "text": clean_text(raw),
            "extension": ext,
        }

    logger.info("Ingestion complete — %d documents loaded.", len(docs))
    return docs

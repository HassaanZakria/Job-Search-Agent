"""
src/classifier.py
-----------------
Classifies document text into one of five categories:

  • Invoice
  • Resume
  • Utility Bill
  • Other
  • Unclassifiable

Strategy (two-tier, fully local):
  1. Keyword scoring — fast, deterministic, zero dependencies beyond stdlib.
     Each category has a weighted keyword set; the category with the highest
     normalised score wins if it clears a confidence threshold.

  2. Zero-shot transformer (optional) — used as a fallback when the keyword
     scorer returns low confidence.  Requires the 'transformers' package and
     a downloaded model (facebook/bart-large-mnli or cross-encoder/nli-*).
     Pass use_transformer=False (default) to skip this entirely.

Public API:
  classify(text: str, use_transformer: bool = False) -> dict
    Returns {"label": str, "confidence": float, "method": str}
"""

import re
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# ── Keyword taxonomy ──────────────────────────────────────────────────────────
# Each entry is (pattern, weight).  Patterns are case-insensitive.

KEYWORD_RULES: dict[str, list[tuple[str, float]]] = {
    "Invoice": [
        (r"\binvoice\b",            3.0),
        (r"\binvoice\s*#?\s*:?\s*[A-Z0-9\-]+", 3.0),
        (r"\binv[-\s]?\d+",         2.5),
        (r"\bbill\s+to\b",          2.0),
        (r"\btotal\s+(amount|due)\b", 2.0),
        (r"\bsubtotal\b",           1.5),
        (r"\btax\s+invoice\b",      3.0),
        (r"\bpayment\s+due\b",      1.5),
        (r"\bdue\s+date\b",         1.0),
        (r"\bquantity\b",           1.0),
        (r"\bunit\s+price\b",       1.5),
        (r"\bvat\b",                1.0),
        (r"\bremit\b",              1.0),
        (r"\bpurchase\s+order\b",   1.5),
        (r"\bvendor\b",             1.0),
        (r"\bnet[\s-]?\d+\b",       1.0),   # Net-30, Net 15 etc.
    ],

    "Resume": [
        (r"\bresume\b",             3.0),
        (r"\bcurriculum\s+vitae\b", 3.0),
        (r"\bcv\b",                 1.5),
        (r"\bwork\s+experience\b",  2.5),
        (r"\bprofessional\s+experience\b", 2.5),
        (r"\bemployment\s+history\b", 2.5),
        (r"\beducation\b",          1.5),
        (r"\bskills\b",             1.5),
        (r"\bcertifications?\b",    1.0),
        (r"\bobjective\b",          1.0),
        (r"\bsummary\b",            0.8),
        (r"\breferences?\b",        1.0),
        (r"\blinkedin\b",           2.0),
        (r"\bph\.?d\b",             1.0),
        (r"\bb\.?sc\b",             1.0),
        (r"\bm\.?sc\b",             1.0),
        (r"\bpresent\b",            0.5),   # "2022–Present" common in resumes
        (r"\b(senior|junior|lead)\s+\w+\s+(engineer|developer|analyst|manager)\b", 2.0),
    ],

    "Utility Bill": [
        (r"\butility\b",            2.5),
        (r"\belectricity\s+bill\b", 3.0),
        (r"\bwater\s+bill\b",       3.0),
        (r"\bgas\s+bill\b",         3.0),
        (r"\baccount\s+number\b",   1.5),
        (r"\bacct\s*#?\s*:?\s*[\w\-]+", 1.5),
        (r"\bservice\s+address\b",  2.0),
        (r"\bbilling\s+period\b",   2.5),
        (r"\bmeter\s+reading\b",    3.0),
        (r"\bkwh\b",                3.0),
        (r"\btherms?\b",            2.5),
        (r"\bgallons?\b",           1.5),
        (r"\bconsumption\b",        2.0),
        (r"\benergy\s+charge\b",    2.5),
        (r"\bdistribution\s+charge\b", 2.5),
        (r"\bstormwater\b",         2.5),
        (r"\belectric\s+company\b", 2.0),
        (r"\butility\s+district\b", 2.5),
        (r"\bamount\s+due\b",       1.0),
    ],
}

LABELS = list(KEYWORD_RULES.keys()) + ["Other", "Unclassifiable"]

# Confidence thresholds
KEYWORD_WIN_THRESHOLD     = 2.0    # raw score to be considered a win
KEYWORD_MARGIN_RATIO      = 1.4    # winner must be 1.4× runner-up
UNCLASSIFIABLE_THRESHOLD  = 0.5    # below this → Unclassifiable


# ── Keyword scorer ────────────────────────────────────────────────────────────

def _score_keywords(text: str) -> dict[str, float]:
    """Return a raw keyword score for each primary category."""
    text_lower = text.lower()
    scores: dict[str, float] = {}

    for label, rules in KEYWORD_RULES.items():
        total = 0.0
        for pattern, weight in rules:
            matches = re.findall(pattern, text_lower)
            # Cap each pattern contribution to avoid single keyword domination
            total += min(len(matches), 3) * weight
        scores[label] = total

    return scores


def _keyword_classify(text: str) -> dict:
    """
    Run keyword scoring and return a result dict.

    confidence: normalised score of the winner (0-1 via softmax-like).
    """
    scores = _score_keywords(text)

    if not any(v > 0 for v in scores.values()):
        return {"label": "Unclassifiable", "confidence": 0.0, "scores": scores}

    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    best_label, best_score = sorted_scores[0]
    second_score = sorted_scores[1][1] if len(sorted_scores) > 1 else 0.0

    # Normalise to [0, 1] using a simple ratio
    total = sum(scores.values()) or 1
    confidence = best_score / total

    # Reject if absolute score too low → Unclassifiable
    if best_score < UNCLASSIFIABLE_THRESHOLD:
        return {"label": "Unclassifiable", "confidence": confidence, "scores": scores}

    # Reject if winner doesn't clearly beat runner-up → "Other"
    if second_score > 0 and best_score / second_score < KEYWORD_MARGIN_RATIO:
        # Still classify but lower confidence — let transformer decide if enabled
        return {
            "label": best_label,
            "confidence": confidence * 0.6,  # penalise ambiguous result
            "scores": scores,
        }

    return {"label": best_label, "confidence": confidence, "scores": scores}


# ── Zero-shot transformer (optional) ─────────────────────────────────────────

_transformer_pipeline = None


def _load_transformer():
    """Lazy-load the zero-shot classification pipeline (downloads on first use)."""
    global _transformer_pipeline
    if _transformer_pipeline is not None:
        return _transformer_pipeline
    try:
        from transformers import pipeline
        logger.info("Loading zero-shot classifier (this may download a model)…")
        _transformer_pipeline = pipeline(
            "zero-shot-classification",
            model="cross-encoder/nli-MiniLM2-L6-H768",  # ~120 MB, fast
            device=-1,   # CPU
        )
        logger.info("Zero-shot classifier loaded.")
        return _transformer_pipeline
    except Exception as exc:
        logger.warning("Could not load transformer pipeline: %s", exc)
        return None


def _transformer_classify(text: str) -> Optional[dict]:
    """Run zero-shot classification and return result or None on failure."""
    pipe = _load_transformer()
    if pipe is None:
        return None

    candidate_labels = ["Invoice", "Resume", "Utility Bill", "Legal Document",
                        "Research Article", "Meeting Notes", "Other"]

    # Truncate to first 512 words to keep inference fast
    snippet = " ".join(text.split()[:512])

    try:
        result = pipe(snippet, candidate_labels=candidate_labels, multi_label=False)
        label = result["labels"][0]
        score = result["scores"][0]
        # Map fine-grained "Other" categories → "Other"
        if label not in ("Invoice", "Resume", "Utility Bill"):
            label = "Other"
        return {"label": label, "confidence": score}
    except Exception as exc:
        logger.warning("Transformer inference failed: %s", exc)
        return None


# ── Public API ────────────────────────────────────────────────────────────────

#: Threshold below which we invoke the transformer fallback (if enabled)
FALLBACK_CONFIDENCE = 0.40


def classify(text: str, use_transformer: bool = False) -> dict:
    """
    Classify *text* into one of: Invoice | Resume | Utility Bill | Other | Unclassifiable.

    Parameters
    ----------
    text : str
        Cleaned document text.
    use_transformer : bool
        If True, invoke a local zero-shot NLI model when keyword confidence
        is low.  Requires 'transformers' and a downloaded model.

    Returns
    -------
    dict
        {
          "label":      str,    # predicted category
          "confidence": float,  # 0–1
          "method":     str,    # "keyword" | "transformer" | "fallback"
        }
    """
    if not text or not text.strip():
        return {"label": "Unclassifiable", "confidence": 0.0, "method": "keyword"}

    kw_result = _keyword_classify(text)
    label = kw_result["label"]
    confidence = kw_result["confidence"]

    # High-confidence keyword hit → done
    if confidence >= FALLBACK_CONFIDENCE and label not in ("Unclassifiable",):
        return {"label": label, "confidence": round(confidence, 4), "method": "keyword"}

    # Low confidence → try transformer if enabled
    if use_transformer:
        tr_result = _transformer_classify(text)
        if tr_result and tr_result["confidence"] > confidence:
            return {
                "label": tr_result["label"],
                "confidence": round(tr_result["confidence"], 4),
                "method": "transformer",
            }

    # Default: return keyword result even if low-confidence
    # Rule: if document has substantial content but no category keyword matches,
    # it is "Other" (recognisable document, just outside the three main types).
    # "Unclassifiable" is reserved for empty / corrupt / unreadable documents.
    word_count = len(text.split())
    if label == "Unclassifiable" or confidence < 0.10:
        # Has real content → Other; essentially empty → Unclassifiable
        final_label = "Other" if word_count >= 20 else "Unclassifiable"
    else:
        final_label = label if label in KEYWORD_RULES else "Other"

    return {
        "label": final_label,
        "confidence": round(confidence, 4),
        "method": "keyword",
    }

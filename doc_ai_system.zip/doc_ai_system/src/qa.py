"""
src/qa.py  (OPTIONAL BONUS)
--------------------------
Local Retrieval-Augmented Generation (RAG) question-answering using:
  • FAISS retrieval (src/retrieval.py) for relevant context
  • A local GGUF-format LLM via llama-cpp-python (e.g. Mistral-7B, LLaMA-3)

No internet connection or paid API required.

Setup:
  1. pip install llama-cpp-python
  2. Download a GGUF model, e.g.:
       wget https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/
            resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf
  3. Set MODEL_PATH to its local path.

Public API:
  ask(index, question, model_path, top_k=3) -> str
"""

import logging
from typing import Optional

from .retrieval import RetrievalIndex, search as retrieval_search

logger = logging.getLogger(__name__)

# Default model path — override via CLI flag or environment variable
DEFAULT_MODEL_PATH = "./models/mistral-7b-instruct-v0.2.Q4_K_M.gguf"


# ── Prompt template ───────────────────────────────────────────────────────────

PROMPT_TEMPLATE = """<s>[INST]
You are a helpful document assistant.  Answer the question using ONLY the
context excerpts provided below.  If the answer is not found in the context,
say "I could not find that information in the provided documents."

Context:
{context}

Question: {question}
[/INST]"""


def _build_context(results: list[dict]) -> str:
    """Format retrieval results into a numbered context block."""
    parts = []
    for i, r in enumerate(results, 1):
        parts.append(
            f"[{i}] File: {r['filename']}  (Type: {r['label']})\n{r['snippet']}"
        )
    return "\n\n".join(parts)


# ── LLM loader ────────────────────────────────────────────────────────────────

_llm_cache: dict[str, object] = {}


def _load_llm(model_path: str, n_ctx: int = 4096, n_threads: int = 4):
    """Lazy-load a llama-cpp-python Llama model."""
    if model_path in _llm_cache:
        return _llm_cache[model_path]
    try:
        from llama_cpp import Llama
        logger.info("Loading LLM from '%s'…", model_path)
        llm = Llama(
            model_path=model_path,
            n_ctx=n_ctx,
            n_threads=n_threads,
            verbose=False,
        )
        _llm_cache[model_path] = llm
        logger.info("LLM loaded.")
        return llm
    except ImportError:
        raise RuntimeError(
            "llama-cpp-python is not installed.  "
            "Run: pip install llama-cpp-python"
        )
    except Exception as exc:
        raise RuntimeError(f"Could not load LLM from '{model_path}': {exc}") from exc


# ── Public API ────────────────────────────────────────────────────────────────

def ask(
    index: RetrievalIndex,
    question: str,
    model_path: str = DEFAULT_MODEL_PATH,
    top_k: int = 3,
    max_tokens: int = 512,
    temperature: float = 0.2,
) -> str:
    """
    Answer *question* using RAG over the document index.

    Parameters
    ----------
    index      : RetrievalIndex  — built by retrieval.build_index()
    question   : str             — natural-language question
    model_path : str             — path to a local GGUF model file
    top_k      : int             — number of retrieved chunks to use as context
    max_tokens : int             — LLM generation budget
    temperature: float           — sampling temperature (lower = more factual)

    Returns
    -------
    str — the model's answer
    """
    # Step 1: Retrieve relevant chunks
    results = retrieval_search(index, question, top_k=top_k)
    if not results:
        return "No relevant documents found for your question."

    context = _build_context(results)
    prompt  = PROMPT_TEMPLATE.format(context=context, question=question)

    logger.info("Running LLM inference (this may take a moment on CPU)…")

    # Step 2: Generate answer
    llm = _load_llm(model_path)
    response = llm(
        prompt,
        max_tokens=max_tokens,
        temperature=temperature,
        stop=["</s>", "[INST]"],
        echo=False,
    )

    answer = response["choices"][0]["text"].strip()

    # Step 3: Append source citations
    sources = "\n".join(
        f"  • {r['filename']} (score: {r['score']:.3f})" for r in results
    )
    return f"{answer}\n\nSources:\n{sources}"

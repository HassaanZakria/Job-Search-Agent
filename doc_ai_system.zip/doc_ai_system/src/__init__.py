"""
doc_ai_system.src
-----------------
Local AI document-processing pipeline.
"""

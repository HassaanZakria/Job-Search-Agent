"""
src/extractor.py
----------------
Extracts structured fields from classified document text using regex patterns
and heuristics.  No ML models are required for this module.

Extracted fields by type:
  Invoice      → invoice_number, date, company, total_amount
  Resume       → name, email, phone, experience_years
  Utility Bill → account_number, date, usage_kwh, amount_due
  Other / Unclassifiable → {} (empty)

Public API:
  extract(text: str, label: str) -> dict
"""

import re
import logging
from typing import Optional

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
#  Shared helpers
# ══════════════════════════════════════════════════════════════════════════════

def _first_match(patterns: list[str], text: str,
                 group: int = 1, flags: int = re.IGNORECASE) -> Optional[str]:
    """Try each pattern in order, return the first capturing group that matches."""
    for pat in patterns:
        m = re.search(pat, text, flags)
        if m:
            try:
                return m.group(group).strip()
            except IndexError:
                return m.group(0).strip()
    return None


def _parse_amount(raw: str) -> Optional[float]:
    """Convert '$1,234.56' or '1234,56' → 1234.56 float."""
    if not raw:
        return None
    # Remove currency symbols and thousands separators
    cleaned = re.sub(r"[£€$,]", "", raw).strip()
    try:
        return float(cleaned)
    except ValueError:
        return None


def _normalise_date(raw: str) -> str:
    """Return date string as-is — preserves original document formatting."""
    return raw.strip() if raw else ""


# ══════════════════════════════════════════════════════════════════════════════
#  Invoice extractor
# ══════════════════════════════════════════════════════════════════════════════

_INVOICE_NUMBER_PATTERNS = [
    r"invoice\s*(?:number|no\.?|#)\s*[:\-]?\s*([A-Z0-9][\w\-/]{2,20})",
    r"inv(?:oice)?\s*[-#:]\s*([A-Z0-9][\w\-/]{2,20})",
    r"(?:^|\n)\s*([A-Z]{2,5}[-\s]?\d{4,8})\s*(?:\n|$)",
]

_INVOICE_DATE_PATTERNS = [
    r"(?:invoice\s*date|issued?|date)\s*[:\-]?\s*(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})",
    r"(?:invoice\s*date|issued?|date)\s*[:\-]?\s*(\w+ \d{1,2},?\s*\d{4})",
    r"(?:invoice\s*date|issued?|date)\s*[:\-]?\s*(\d{4}[-\/]\d{2}[-\/]\d{2})",
    # Fallback: first standalone date in the document
    r"\b(\d{4}[-\/]\d{2}[-\/]\d{2})\b",
    r"\b(\w+ \d{1,2},?\s*\d{4})\b",
    r"\b(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})\b",
]

_COMPANY_PATTERNS = [
    r"(?:from|vendor|issued by|billed? by|seller)\s*[:\-]?\s*\n\s*(.+)",
    r"(?:from|vendor|issued by|billed? by|seller)\s*[:\-]\s*(.+)",
    r"(?:^|\n)\s*([\w\s&\.,]+(?:Ltd\.?|LLC|Inc\.?|Corp\.?|Co\.?|GmbH|PLC))\b",
]

_TOTAL_PATTERNS = [
    r"total\s+(?:amount\s+)?due\s*[:\-]?\s*\$?([\d,]+\.?\d{0,2})",
    r"total\s+amount\s*[:\-]?\s*\$?([\d,]+\.?\d{0,2})",
    r"amount\s+due\s*[:\-]?\s*\$?([\d,]+\.?\d{0,2})",
    r"(?:grand\s+)?total\s*[:\-]?\s*\$?([\d,]+\.?\d{0,2})",
    r"total\s*\n\s*\$?([\d,]+\.?\d{0,2})",
]


def extract_invoice(text: str) -> dict:
    invoice_number = _first_match(_INVOICE_NUMBER_PATTERNS, text)
    date_raw = _first_match(_INVOICE_DATE_PATTERNS, text)
    company_raw = _first_match(_COMPANY_PATTERNS, text)
    total_raw = _first_match(_TOTAL_PATTERNS, text)

    # Clean company name: strip extra whitespace/punctuation
    company = None
    if company_raw:
        company = re.sub(r"\s+", " ", company_raw).strip(" ,.-")

    return {
        "invoice_number": invoice_number,
        "date": _normalise_date(date_raw) if date_raw else None,
        "company": company,
        "total_amount": _parse_amount(total_raw),
    }


# ══════════════════════════════════════════════════════════════════════════════
#  Resume extractor
# ══════════════════════════════════════════════════════════════════════════════

_EMAIL_PATTERN   = r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
_PHONE_PATTERNS  = [
    r"(\+?[\d\(][\d\s\-\.\(\)]{7,15}\d)",   # international / US / UK (allow leading paren)
]

_EXPERIENCE_YEAR_PATTERNS = [
    # "7 years of experience"
    r"(\d+)\+?\s+years?\s+of\s+(?:professional\s+)?experience",
    # "(2018–2025)" style job spans — count distinct year ranges
]


def _infer_experience_years(text: str) -> Optional[int]:
    """
    Estimate total experience years from the resume.

    Priority:
      1. Explicit statement "X years of experience".
      2. Sum of job date ranges in "YYYY – YYYY" or "YYYY – Present" format.
    """
    # 1. Explicit statement
    m = re.search(
        r"(\d+)\+?\s+years?\s+of\s+(?:professional\s+|work\s+)?experience",
        text, re.IGNORECASE
    )
    if m:
        return int(m.group(1))

    # 2. Parse year ranges and accumulate
    import datetime
    current_year = datetime.datetime.now().year
    ranges = re.findall(
        r"(\d{4})\s*[–\-—to]+\s*(Present|\d{4})",
        text, re.IGNORECASE
    )
    if ranges:
        total = 0
        for start_str, end_str in ranges:
            start = int(start_str)
            end = current_year if end_str.lower() == "present" else int(end_str)
            if 1950 < start <= current_year and start <= end:
                total += end - start
        return total if total > 0 else None

    return None


def extract_resume(text: str) -> dict:
    # Email
    email_m = re.search(_EMAIL_PATTERN, text)
    email = email_m.group(0) if email_m else None

    # Phone
    phone = _first_match(_PHONE_PATTERNS, text)
    if phone:
        # Remove email address segments accidentally captured
        phone = re.sub(r"[a-zA-Z]", "", phone).strip()

    # Name: heuristic — first non-blank line that is mostly title-case words
    name = None
    for line in text.split("\n")[:10]:
        line = line.strip()
        if not line:
            continue
        # Skip lines that look like headers/labels
        if re.match(r"(?i)^\s*(resume|curriculum|cv|profile|objective)\s*$", line):
            continue
        words = line.split()
        if 1 < len(words) <= 6 and all(
            w[0].isupper() or not w[0].isalpha() for w in words if w
        ):
            # Discard lines that contain typical non-name tokens
            if not re.search(r"[@|/\\|:\d]", line):
                name = line
                break

    experience_years = _infer_experience_years(text)

    return {
        "name": name,
        "email": email,
        "phone": phone,
        "experience_years": experience_years,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  Utility Bill extractor
# ══════════════════════════════════════════════════════════════════════════════

_ACCOUNT_PATTERNS = [
    r"account\s*(?:number|no\.?|#)\s*[:\-]?\s*([\w\-\.]{5,20})",
    r"acct\s*(?:no\.?|#)?\s*[:\-]?\s*([\w\-\.]{5,20})",
    r"account\s*[:\-]\s*([\w\-\.]{5,20})",
]

_BILL_DATE_PATTERNS = [
    r"(?:bill|statement|invoice)\s*date\s*[:\-]?\s*(\d{4}[-\/]\d{2}[-\/]\d{2})",
    r"(?:bill|statement|invoice)\s*date\s*[:\-]?\s*(\w+ \d{1,2},?\s*\d{4})",
    r"(?:bill|statement|invoice)\s*date\s*[:\-]?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4})",
    r"\b(\d{4}[-\/]\d{2}[-\/]\d{2})\b",
    r"\b(\w+ \d{1,2},?\s*\d{4})\b",
]

_KWH_PATTERNS = [
    r"usage\s*(?:this\s*period)?\s*[:\-]?\s*([\d,]+\.?\d*)\s*kwh",
    r"electricity\s+usage\s*[:\-]?\s*([\d,]+\.?\d*)\s*kwh",
    r"(?:energy|power)\s+consumption\s*[:\-]?\s*([\d,]+\.?\d*)\s*kwh",
    r"([\d,]+\.?\d*)\s*kwh\b",            # fallback: any kWh mention
]

_AMOUNT_DUE_PATTERNS = [
    r"total\s+amount\s+due\s*[:\-]?\s*\$?([\d,]+\.?\d{0,2})",
    r"amount\s+due\s*[:\-]?\s*\$?([\d,]+\.?\d{0,2})",
    r"total\s+due\s*[:\-]?\s*\$?([\d,]+\.?\d{0,2})",
    r"total\s*[:\-]?\s*\$?([\d,]+\.?\d{0,2})\s*$",
]


def extract_utility_bill(text: str) -> dict:
    account_number = _first_match(_ACCOUNT_PATTERNS, text)
    date_raw = _first_match(_BILL_DATE_PATTERNS, text)
    kwh_raw = _first_match(_KWH_PATTERNS, text)
    amount_raw = _first_match(_AMOUNT_DUE_PATTERNS, text)

    # kWh can be "442" or "615"
    usage_kwh = None
    if kwh_raw:
        try:
            usage_kwh = float(re.sub(r",", "", kwh_raw))
        except ValueError:
            pass

    return {
        "account_number": account_number,
        "date": _normalise_date(date_raw) if date_raw else None,
        "usage_kwh": usage_kwh,
        "amount_due": _parse_amount(amount_raw),
    }


# ══════════════════════════════════════════════════════════════════════════════
#  Public API
# ══════════════════════════════════════════════════════════════════════════════

_EXTRACTORS = {
    "Invoice":      extract_invoice,
    "Resume":       extract_resume,
    "Utility Bill": extract_utility_bill,
}


def extract(text: str, label: str) -> dict:
    """
    Extract structured fields from *text* based on *label*.

    Parameters
    ----------
    text  : str  — cleaned document text
    label : str  — classification label (e.g. "Invoice")

    Returns
    -------
    dict  — extracted fields; empty dict for Other / Unclassifiable.
    """
    extractor = _EXTRACTORS.get(label)
    if extractor is None:
        logger.debug("No extractor for label '%s' — skipping extraction.", label)
        return {}

    try:
        fields = extractor(text)
        logger.debug("Extracted from %s: %s", label, fields)
        return fields
    except Exception as exc:
        logger.error("Extraction error for label '%s': %s", label, exc)
        return {}

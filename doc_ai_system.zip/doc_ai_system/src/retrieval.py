"""
src/retrieval.py
----------------
Local semantic search using SentenceTransformers + FAISS.

Documents are split into overlapping chunks, embedded with a lightweight
sentence-transformer model (all-MiniLM-L6-v2, ~80 MB), and indexed in a
FAISS flat-L2 index stored entirely in memory (no server needed).

Public API:
  build_index(docs: dict) -> RetrievalIndex
  search(index: RetrievalIndex, query: str, top_k: int = 5) -> list[dict]
  save_index(index: RetrievalIndex, path: str) -> None
  load_index(path: str) -> RetrievalIndex

  RetrievalIndex is a plain dataclass — no external state.
"""

from __future__ import annotations

import json
import logging
import os
import pickle
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────

DEFAULT_MODEL  = "all-MiniLM-L6-v2"   # ~80 MB, fast, good quality
CHUNK_SIZE     = 200                   # words per chunk
CHUNK_OVERLAP  = 40                    # overlap to preserve context


# ── Chunking ──────────────────────────────────────────────────────────────────

def _chunk_text(text: str, chunk_size: int = CHUNK_SIZE,
                overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split *text* into overlapping word-windows."""
    words = text.split()
    chunks = []
    step = chunk_size - overlap
    for start in range(0, max(1, len(words) - overlap), step):
        chunk = " ".join(words[start : start + chunk_size])
        if chunk.strip():
            chunks.append(chunk)
    return chunks or [text[:1000]]   # fallback for very short docs


# ── Index dataclass ───────────────────────────────────────────────────────────

@dataclass
class RetrievalIndex:
    """
    In-memory FAISS index plus the metadata needed to map results back to docs.
    """
    faiss_index: object                      # faiss.IndexFlatL2
    chunk_meta:  list[dict]                  # [{filename, chunk_id, text}, ...]
    model_name:  str = DEFAULT_MODEL
    doc_labels:  dict[str, str] = field(default_factory=dict)  # filename→label


# ── Embedding helper ──────────────────────────────────────────────────────────

_encoder_cache: dict[str, object] = {}


def _get_encoder(model_name: str = DEFAULT_MODEL):
    """Lazy-load and cache the SentenceTransformer encoder."""
    if model_name not in _encoder_cache:
        from sentence_transformers import SentenceTransformer
        logger.info("Loading embedding model '%s' (first run may download)…", model_name)
        _encoder_cache[model_name] = SentenceTransformer(model_name)
        logger.info("Embedding model ready.")
    return _encoder_cache[model_name]


def _embed(texts: list[str], model_name: str = DEFAULT_MODEL) -> np.ndarray:
    """Encode *texts* into float32 embeddings, shape (N, dim)."""
    encoder = _get_encoder(model_name)
    embeddings = encoder.encode(
        texts,
        batch_size=32,
        show_progress_bar=len(texts) > 20,
        convert_to_numpy=True,
        normalize_embeddings=True,   # cosine via inner-product on unit vectors
    )
    return embeddings.astype(np.float32)


# ── Index builder ─────────────────────────────────────────────────────────────

def build_index(docs: dict, model_name: str = DEFAULT_MODEL) -> RetrievalIndex:
    """
    Build a FAISS index from a collection of documents.

    Parameters
    ----------
    docs : dict
        {filename: {"text": str, "label": str, ...}}  (output of pipeline)
    model_name : str
        SentenceTransformer model name.

    Returns
    -------
    RetrievalIndex
    """
    import faiss

    all_chunks: list[str] = []
    chunk_meta: list[dict] = []
    doc_labels: dict[str, str] = {}

    for filename, doc in docs.items():
        text  = doc.get("text", "")
        label = doc.get("label", "Unknown")
        doc_labels[filename] = label

        chunks = _chunk_text(text)
        for i, chunk in enumerate(chunks):
            all_chunks.append(chunk)
            chunk_meta.append({
                "filename": filename,
                "chunk_id": i,
                "text":     chunk,
                "label":    label,
            })

    if not all_chunks:
        raise ValueError("No text content found — cannot build index.")

    logger.info("Embedding %d chunks from %d document(s)…", len(all_chunks), len(docs))
    embeddings = _embed(all_chunks, model_name)

    dim = embeddings.shape[1]
    # IndexFlatIP = inner-product (cosine similarity on normalised vectors)
    faiss_index = faiss.IndexFlatIP(dim)
    faiss_index.add(embeddings)
    logger.info("FAISS index built: %d vectors, dim=%d", faiss_index.ntotal, dim)

    return RetrievalIndex(
        faiss_index=faiss_index,
        chunk_meta=chunk_meta,
        model_name=model_name,
        doc_labels=doc_labels,
    )


# ── Search ────────────────────────────────────────────────────────────────────

def search(
    index: RetrievalIndex,
    query: str,
    top_k: int = 5,
) -> list[dict]:
    """
    Semantic search over the indexed documents.

    Parameters
    ----------
    index : RetrievalIndex
    query : str     — natural language query
    top_k : int     — number of results to return

    Returns
    -------
    list of dicts, each containing:
      filename, label, score (0-1 cosine similarity), snippet
    """
    q_emb = _embed([query], model_name=index.model_name)

    distances, indices = index.faiss_index.search(q_emb, min(top_k * 3, index.faiss_index.ntotal))

    # De-duplicate by filename (keep best score per doc)
    seen: dict[str, dict] = {}
    for dist, idx in zip(distances[0], indices[0]):
        if idx < 0:
            continue
        meta  = index.chunk_meta[idx]
        fname = meta["filename"]
        score = float(dist)   # inner-product on unit vectors ≈ cosine
        if fname not in seen or score > seen[fname]["score"]:
            seen[fname] = {
                "filename": fname,
                "label":    meta["label"],
                "score":    round(score, 4),
                "snippet":  meta["text"][:300] + ("…" if len(meta["text"]) > 300 else ""),
            }

    results = sorted(seen.values(), key=lambda x: x["score"], reverse=True)
    return results[:top_k]


# ── Persistence ───────────────────────────────────────────────────────────────

def save_index(index: RetrievalIndex, path: str) -> None:
    """Serialise the index to *path* (a directory)."""
    import faiss
    os.makedirs(path, exist_ok=True)
    faiss.write_index(index.faiss_index, os.path.join(path, "faiss.index"))
    meta = {
        "chunk_meta": index.chunk_meta,
        "model_name": index.model_name,
        "doc_labels": index.doc_labels,
    }
    with open(os.path.join(path, "meta.json"), "w") as fh:
        json.dump(meta, fh, indent=2)
    logger.info("Index saved to '%s'", path)


def load_index(path: str) -> RetrievalIndex:
    """Load a previously saved index from *path*."""
    import faiss
    faiss_index = faiss.read_index(os.path.join(path, "faiss.index"))
    with open(os.path.join(path, "meta.json")) as fh:
        meta = json.load(fh)
    return RetrievalIndex(
        faiss_index=faiss_index,
        chunk_meta=meta["chunk_meta"],
        model_name=meta["model_name"],
        doc_labels=meta.get("doc_labels", {}),
    )

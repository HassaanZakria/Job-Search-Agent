#!/usr/bin/env python3
"""
main.py — Local AI Document Processing Pipeline
================================================

Usage examples:
  # Process all documents and write output.json
  python main.py process --docs sample_docs/

  # Semantic search
  python main.py search --query "payments due in January"

  # Interactive search REPL
  python main.py search --interactive

  # Optional: RAG question-answering (requires llama-cpp-python + GGUF model)
  python main.py ask --question "Which invoices are from ACME?" \\
                     --model ./models/mistral-7b-instruct-v0.2.Q4_K_M.gguf

  # Full help
  python main.py --help
"""

import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path

# ── Logging setup ─────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("main")

# ── Paths ─────────────────────────────────────────────────────────────────────

DEFAULT_DOCS_FOLDER  = "sample_docs"
DEFAULT_OUTPUT_FILE  = "output.json"
DEFAULT_INDEX_FOLDER = ".index_cache"


# ── Pipeline helpers ──────────────────────────────────────────────────────────

def run_pipeline(
    docs_folder: str,
    output_file: str,
    use_transformer: bool = False,
    save_index: bool = True,
    index_folder: str = DEFAULT_INDEX_FOLDER,
) -> tuple[dict, object]:
    """
    Full processing pipeline:
      1. Ingest documents
      2. Classify each document
      3. Extract structured fields
      4. Build FAISS retrieval index

    Returns (results_dict, retrieval_index).
    """
    from src.ingest    import load_documents
    from src.classifier import classify
    from src.extractor  import extract
    from src.retrieval  import build_index, save_index as save_idx

    # ── 1. Ingest ─────────────────────────────────────────────────────────────
    logger.info("═══ Step 1/4 — Ingesting documents from '%s'", docs_folder)
    t0 = time.time()
    docs = load_documents(docs_folder)
    logger.info("    Loaded %d documents (%.1fs)", len(docs), time.time() - t0)

    if not docs:
        logger.error("No documents found in '%s'. Exiting.", docs_folder)
        sys.exit(1)

    # ── 2 & 3. Classify + Extract ─────────────────────────────────────────────
    logger.info("═══ Step 2-3/4 — Classifying and extracting fields")
    results: dict[str, dict] = {}
    retrieval_docs: dict[str, dict] = {}

    for filename, doc_data in docs.items():
        text = doc_data["text"]
        t1 = time.time()
        clf  = classify(text, use_transformer=use_transformer)
        label = clf["label"]
        fields = extract(text, label)

        # Build output record
        record = {"class": label, **fields}
        results[filename] = record

        # Prepare for retrieval index
        retrieval_docs[filename] = {"text": text, "label": label}

        logger.info(
            "  %-30s → %-16s (confidence=%.2f, method=%s, %.2fs)",
            filename, label, clf["confidence"], clf["method"], time.time() - t1,
        )

    # ── 4. Build retrieval index ───────────────────────────────────────────────
    index = None
    try:
        logger.info("═══ Step 4/4 — Building semantic retrieval index")
        t2 = time.time()
        index = build_index(retrieval_docs)
        logger.info("    Index built (%.1fs)", time.time() - t2)

        if save_index:
            save_idx(index, index_folder)

    except ImportError as exc:
        logger.warning(
            "Retrieval index skipped — missing library: %s\n"
            "  Install with: pip install sentence-transformers faiss-cpu", exc
        )
    except Exception as exc:
        logger.warning("Retrieval index build failed: %s", exc)

    # ── Write output.json ─────────────────────────────────────────────────────
    with open(output_file, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2, ensure_ascii=False)
    logger.info("Results written to '%s'", output_file)

    return results, index


def pretty_print_results(results: dict) -> None:
    """Print a human-readable summary table of classification results."""
    print("\n" + "═" * 70)
    print(f"{'File':<32} {'Class':<18} {'Key Fields'}")
    print("─" * 70)
    for filename, data in results.items():
        label = data.get("class", "?")
        # Show a short summary of extracted fields
        fields = {k: v for k, v in data.items() if k != "class" and v is not None}
        if fields:
            first_key = next(iter(fields))
            summary = f"{first_key}={fields[first_key]}"
        else:
            summary = "(no extraction)"
        print(f"  {filename:<30} {label:<18} {summary}")
    print("═" * 70 + "\n")


# ── Sub-commands ──────────────────────────────────────────────────────────────

def cmd_process(args: argparse.Namespace) -> None:
    """Run the full ingestion → classification → extraction → index pipeline."""
    results, _ = run_pipeline(
        docs_folder=args.docs,
        output_file=args.output,
        use_transformer=args.transformer,
        index_folder=args.index_dir,
    )
    pretty_print_results(results)
    print(f"✅  Done.  Results → {args.output}")


def cmd_search(args: argparse.Namespace) -> None:
    """Semantic search over previously built (or freshly built) index."""
    from src.retrieval import load_index, build_index, search as do_search
    from src.ingest import load_documents
    from src.classifier import classify

    # Load or build index
    if os.path.isdir(args.index_dir):
        logger.info("Loading existing index from '%s'", args.index_dir)
        index = load_index(args.index_dir)
    else:
        logger.info(
            "No cached index found — building from '%s' first.", args.docs
        )
        _, index = run_pipeline(args.docs, args.output, index_folder=args.index_dir)
        if index is None:
            logger.error("Could not build index.  Check that sentence-transformers and faiss-cpu are installed.")
            sys.exit(1)

    def _do_query(query: str) -> None:
        results = do_search(index, query, top_k=args.top_k)
        print(f"\n🔍  Query: \"{query}\"")
        print(f"{'Rank':<5} {'Score':<8} {'Label':<16} File")
        print("─" * 65)
        for i, r in enumerate(results, 1):
            print(f"  {i:<4} {r['score']:.4f}   {r['label']:<15} {r['filename']}")
            print(f"       ↳ {r['snippet'][:120]}…")
        print()

    if args.interactive:
        print("\n🔎  Semantic Search — type your query, 'q' to quit")
        while True:
            try:
                q = input("Query> ").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if q.lower() in ("q", "quit", "exit"):
                break
            if q:
                _do_query(q)
    elif args.query:
        _do_query(args.query)
    else:
        print("Provide --query TEXT or --interactive flag.")


def cmd_ask(args: argparse.Namespace) -> None:
    """Optional RAG Q&A using a local GGUF LLM."""
    from src.retrieval import load_index
    from src.qa import ask

    if not os.path.isdir(args.index_dir):
        logger.error(
            "No index found at '%s'. Run 'process' first.", args.index_dir
        )
        sys.exit(1)

    if not os.path.isfile(args.model):
        logger.error(
            "LLM model not found at '%s'. Download a GGUF model and pass its path with --model.",
            args.model
        )
        sys.exit(1)

    index = load_index(args.index_dir)
    answer = ask(index, args.question, model_path=args.model, top_k=args.top_k)
    print(f"\n💬  Question: {args.question}\n")
    print(f"🤖  Answer:\n{answer}\n")


# ── Argument parser ───────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="doc_ai",
        description="Local AI document pipeline — classify, extract, search.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    shared = argparse.ArgumentParser(add_help=False)
    shared.add_argument("--docs",      default=DEFAULT_DOCS_FOLDER,
                        help="Folder containing PDF/TXT documents.")
    shared.add_argument("--output",    default=DEFAULT_OUTPUT_FILE,
                        help="Path for output.json.")
    shared.add_argument("--index-dir", default=DEFAULT_INDEX_FOLDER,
                        help="Directory for the FAISS index cache.")

    sub = parser.add_subparsers(dest="command", required=True)

    # ── process ──
    p_proc = sub.add_parser("process", parents=[shared],
                             help="Ingest, classify, extract, and index documents.")
    p_proc.add_argument("--transformer", action="store_true",
                        help="Use zero-shot transformer fallback for low-confidence docs.")

    # ── search ──
    p_srch = sub.add_parser("search", parents=[shared],
                             help="Semantic search over indexed documents.")
    p_srch.add_argument("--query",       default="",
                        help="Search query string.")
    p_srch.add_argument("--top-k",       type=int, default=5,
                        help="Number of results to return.")
    p_srch.add_argument("--interactive", action="store_true",
                        help="Launch an interactive query REPL.")

    # ── ask (optional bonus) ──
    p_ask = sub.add_parser("ask", parents=[shared],
                            help="[BONUS] RAG Q&A using a local GGUF LLM.")
    p_ask.add_argument("--question", required=True,
                       help="Question to answer using the documents.")
    p_ask.add_argument("--model",    default="./models/mistral-7b-instruct-v0.2.Q4_K_M.gguf",
                       help="Path to a local GGUF model file.")
    p_ask.add_argument("--top-k",   type=int, default=3,
                       help="Number of document chunks to retrieve as context.")

    return parser


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser  = build_parser()
    args    = parser.parse_args()

    dispatch = {
        "process": cmd_process,
        "search":  cmd_search,
        "ask":     cmd_ask,
    }
    dispatch[args.command](args)
